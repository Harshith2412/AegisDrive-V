# AegisDrive-V

**Model-Based Automotive ECU Safety, Security and V-Model Validation Platform** — an open-source,
software-in-the-loop engineering project around an Automatic Emergency Braking (AEB) function, a simulated
Brake ECU and a Body Control Module.

> ⚠️ **Educational simulation only.** Not production software, not certified, no ISO 26262 / ISO 21448 /
> ISO/SAE 21434 compliance is claimed. Standards are used as *inspiration*; see `docs/`.

## Status — v0.3.0: ADAS SOTIF, Fault Tolerance & Model Assurance

Preserved and reproduced v0.2.0 before changes. Current macOS build passes 45 C++ and
34 Python tests; 44 requirements link to passing tests. Added camera/fusion models,
independently validated backup command transport, achieved-deceleration supervision,
continuous within-step contact resolution and ODD-transition correction.

[Technical release report](docs/v0.3.0_release.md) · [Audit](docs/v0.3.0_audit.md) ·
[SOTIF study](docs/v0.3.0_sotif.md) · [Fault containment](docs/v0.3.0_fault_containment.md) ·
[Model assurance](docs/v0.3.0_models.md) · [Evaluation](results/v0.3.0/evaluation.md) ·
[Reproduction](docs/v0.3.0_reproducibility.md)

In the tested original fault scenarios, healthy camera fallback changes FI01 from 20/20
to 0/20 collisions; combined perception plus a healthy backup command path changes FI02
to 0/20. Original radar-only/primary-only configurations remain 20/20. The shared actuator
and Brake ECU have no physical backup; their failure cases still collide. Ghosts cause
false braking, and the fixed 120-case diverse hold-out set retains 29 collisions.

Two genuine SysML v2 files, including all requirement allocations/verification links,
pass the official pilot parser and semantic validator, with a rejected semantic negative
control. This establishes language validity, not complete engineering correctness.
Educational research only: no certification, production-readiness or standards compliance.

Historical release records: [v0.2.0](docs/v0.2.0_release.md), archived source/evidence in
`baseline/v0.2.0/` and `baseline/v0.1.0/`. Historical measurement files are unchanged.

## Vertical slice in one picture
```
radar model ─► ADAS ECU (TTC, FSM, supervisor) ─CAN 0x120─► Brake ECU (validate, timeout, actuator) ─► ego vehicle
                    └────────────CAN 0x130──────► Body ECU ◄──CAN 0x220──┘   (brake lamps, FCW, hazard)
```
ADAS states: DISABLED · STANDBY · MONITORING · WARNING · BRAKING · DEGRADED · FAULT (26 legal transitions, all others rejected and logged).

## Historical v0.1.0 results (preserved; current comparison linked above)
| Scenario | Outcome (20 seeds) |
|---|---|
| S01 normal following | 0 warnings, 0 brake requests |
| S02 lead brakes 6 m/s² @ 50 km/h, 20 m gap | 0/20 collisions, but min gap only **0.58 m** (constant-velocity TTC limitation, OI-002) |
| S03 stationary target @ 50 km/h | 0/20 collisions, stops 2.4–2.6 m short; brake lamp 10 ms after brake active |
| S04 lead decelerates 1.5 m/s² | 0/20 collisions, but AEB **aborted and re-triggered** (OI-003) |
| FI01 radar freezes | detected within 160 ms → DEGRADED → FAULT; **collision 20/20** (single sensor, OI-006) |
| FI02 brake command loss | Brake ECU times out correctly; ADAS doesn't notice → **collision 20/20** (OI-001) |
| Sweep, stationary target | μ 0.9: 0 collisions 10–80 km/h · μ 0.5: collisions 100 % at ≥ 60 km/h (no friction awareness, OI-004) |
| Characterisation | forged frame with recomputed CRC **is accepted** → CRC ≠ security (OI-005, Phase 7) |

With 20 runs per point, "0 collisions" bounds the true rate only below ≈16 % (Wilson 95 %).

## Quick start (validated on macOS)

```sh
python3 -m venv .venv
.venv/bin/pip install -r results/v0.3.0/dependencies.txt
SYSML_PILOT_HOME=/path/to/sysml-0.63.1 PLANTUML_JAR=/path/to/plantuml-1.2026.2.jar scripts/run_v3.sh
```

See the reproduction record for pinned tool downloads, hashes and archived baseline runs.
Original YAML files retain radar-only, primary-only behavior. Redundancy is selected explicitly
in the frozen experiment manifest; it does not imply physically independent backup braking.
ABI 3 requires rebuilding the C++ library and Python bindings together.

## Repository layout
```
docs/            00–04 Phase-0 baseline, 05 design, open issues, phase status, toolchain notes
ecu/include      C ABI types (aegis_types.h, aegis_c_api.h) + C++ headers
ecu/src          ADAS, Brake, Body ECUs, CAN codecs, E2E (CRC-8 + alive counter)
ecu/tests        GoogleTest-style unit tests (tagged TEST-ID / VERIFIES)
sim/aegis_sim    ctypes bindings, virtual CAN, vehicle & radar models, runner, plotting
scenarios        YAML scenarios S01–S04, FI01–FI02
requirements     requirements.yaml (machine-readable DB)
tests/python     integration / system / fault-injection tests
tools            experiment runner, traceability checker, report generator, fallback test runner
results          generated evidence (re-created by scripts/run_all.sh)
```

## Important honesty notes
* v0.1.0 evidence was produced in a Linux sandbox **without CMake, GoogleTest, pytest, pybind11 or python-can**
  (no network). The CMake path is written but was **not executed** there (OI-011). See `docs/toolchain_notes.md`.
* Timing numbers are host FFI wall-clock times, not ECU execution times.
* v0.1.0 MC/DC was not measured. v0.2.0 has partial LLVM MC/DC evidence; see the release record.

## License
MIT — see `LICENSE`.
