#!/usr/bin/env bash
# One command to rebuild, test, run experiments, check traceability and regenerate the report.
# Uses CMake + GoogleTest + pytest when available, otherwise the documented fallbacks.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results
if command -v cmake >/dev/null 2>&1 && [[ "${AEGIS_FORCE_FALLBACK:-0}" != "1" ]]; then
  cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
  cmake --build build -j
  ./build/aegis_ecu_tests --gtest_output=json:results/cpp_test_results.json
  BUILD_KIND=cmake
else
  scripts/build_nocmake.sh
  ./build/aegis_ecu_tests --gtest_output=json:results/cpp_test_results.json
  BUILD_KIND=fallback
fi
if python3 -c "import pytest" 2>/dev/null && [[ "${AEGIS_FORCE_FALLBACK:-0}" != "1" ]]; then
  python3 -m pytest tests/python -q --junitxml=results/python_test_results.xml
  PYRES=results/python_test_results.xml
else
  python3 tools/run_python_tests.py results/python_test_results.json
  PYRES=results/python_test_results.json
fi
python3 tools/run_vertical_slice.py --seeds 20 --out results
if command -v gcov >/dev/null 2>&1 && "${CXX:-c++}" --version | grep -qi "gcc\|g++\|free software"; then
  scripts/coverage.sh || echo "coverage step failed (non-fatal)"
else
  echo "gcov/GCC not available: coverage skipped (on macOS, see docs/toolchain_notes.md)"
fi
python3 tools/trace_check.py --py-results "$PYRES" || TRACE_FAIL=1
python3 tools/make_report.py --build-kind "$BUILD_KIND"
exit "${TRACE_FAIL:-0}"
