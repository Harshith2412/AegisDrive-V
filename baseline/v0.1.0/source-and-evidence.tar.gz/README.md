# AegisDrive-V

**Model-Based Automotive ECU Safety, Security and V-Model Validation Platform** — an open-source,
software-in-the-loop engineering project around an Automatic Emergency Braking (AEB) function, a simulated
Brake ECU and a Body Control Module.

> ⚠️ **Educational simulation only.** Not production software, not certified, no ISO 26262 / ISO 21448 /
> ISO/SAE 21434 compliance is claimed. Standards are used as *inspiration*; see `docs/`.

## Status — v0.1.0 (Phase 0 + first executable vertical slice)
| | |
|---|---|
| ✅ Done | Engineering baseline (charter, item definition, boundary, ODD, assumptions) · C++17 ADAS/Brake/Body ECUs with E2E-protected CAN frames · C ABI + Python ctypes bindings (one implementation of every algorithm) · deterministic SiL harness · 6 scenarios incl. 2 fault injections · 34 C++ + 19 Python tests · gcov coverage · requirement DB (33 reqs) + automated traceability checker · generated report & plots |
| 🟡 Partial | Safety mechanisms exist and are tested, but **HARA/FSC/TSC/FMEA/FTA have not been done**; FSR/TSR are provisional |
| ⬜ Not started | SysML v2 / PlantUML models, SOTIF analysis, TARA + cybersecurity controls (A01–A07), camera & fusion, RQ1–RQ5 experiments, dashboard |

Details: [`docs/phase_status.md`](docs/phase_status.md) · Known issues: [`docs/open_issues.md`](docs/open_issues.md)

## Vertical slice in one picture
```
radar model ─► ADAS ECU (TTC, FSM, supervisor) ─CAN 0x120─► Brake ECU (validate, timeout, actuator) ─► ego vehicle
                    └────────────CAN 0x130──────► Body ECU ◄──CAN 0x220──┘   (brake lamps, FCW, hazard)
```
ADAS states: DISABLED · STANDBY · MONITORING · WARNING · BRAKING · DEGRADED · FAULT (26 legal transitions, all others rejected and logged).

## Headline results (generated — see `results/vertical_slice_report.md`)
| Scenario | Outcome (20 seeds) |
|---|---|
| S01 normal following | 0 warnings, 0 brake requests |
| S02 lead brakes 6 m/s² @ 50 km/h, 20 m gap | 0/20 collisions, but min gap only **0.58 m** (constant-velocity TTC limitation, OI-002) |
| S03 stationary target @ 50 km/h | 0/20 collisions, stops 2.4–2.6 m short; brake lamp 10 ms after brake active |
| S04 lead decelerates 1.5 m/s² | 0/20 collisions, but AEB **aborted and re-triggered** (OI-003) |
| FI01 radar freezes | detected within 160 ms → DEGRADED → FAULT; **collision 20/20** (single sensor, OI-006) |
| FI02 brake command loss | Brake ECU times out correctly; ADAS doesn't notice → **collision 20/20** (OI-001) |
| Sweep, stationary target | μ 0.9: 0 collisions 10–80 km/h · μ 0.5: collisions 100 % at ≥ 60 km/h (no friction awareness, OI-004) |
| Characterisation | forged frame with recomputed CRC **is accepted** → CRC ≠ security (OI-005, Phase 7) |

With 20 runs per point, "0 collisions" bounds the true rate only below ≈16 % (Wilson 95 %).

## Quick start (macOS / Linux)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
scripts/run_all.sh            # build → C++ tests → Python tests → experiments → coverage → traceability → report
```
`run_all.sh` uses CMake + GoogleTest (FetchContent) + pytest when available. Without them it uses documented
fallbacks (`scripts/build_nocmake.sh`, `third_party/minitest`, `tools/run_python_tests.py`); force with
`AEGIS_FORCE_FALLBACK=1`.

Individual steps:
```bash
cmake -S . -B build && cmake --build build -j && ./build/aegis_ecu_tests   # C++ build + unit tests
python3 -m pytest tests/python -q                                          # integration/system tests
python3 tools/run_vertical_slice.py --seeds 20                             # scenarios, sweep, plots
python3 tools/trace_check.py                                               # traceability (non-zero exit on gaps)
scripts/coverage.sh                                                        # gcov statement/branch (GCC only)
```

## Repository layout
```
docs/            00–04 Phase-0 baseline, 05 design, open issues, phase status, toolchain notes
ecu/include      C ABI types (aegis_types.h, aegis_c_api.h) + C++ headers
ecu/src          ADAS, Brake, Body ECUs, CAN codecs, E2E (CRC-8 + alive counter)
ecu/tests        GoogleTest-style unit tests (tagged TEST-ID / VERIFIES)
sim/aegis_sim    ctypes bindings, virtual CAN, vehicle & radar models, runner, plotting
scenarios        YAML scenarios S01–S04, FI01–FI02
requirements     requirements.yaml (machine-readable DB)
tests/python     integration / system / fault-injection tests
tools            experiment runner, traceability checker, report generator, fallback test runner
results          generated evidence (re-created by scripts/run_all.sh)
```

## Important honesty notes
* v0.1.0 evidence was produced in a Linux sandbox **without CMake, GoogleTest, pytest, pybind11 or python-can**
  (no network). The CMake path is written but was **not executed** there (OI-011). See `docs/toolchain_notes.md`.
* Timing numbers are host FFI wall-clock times, not ECU execution times.
* MC/DC coverage is **not** measured.

## License
MIT — see `LICENSE`.
