"""Closed-loop SiL runner: vehicles + radar + ADAS/Brake/Body ECUs (real C++) + virtual CAN.

Step order at simulation time t_k (dt = 10 ms):
  1. bus.advance()            frames sent at t_{k-1} become receivable (1-cycle latency)
  2. radar.update()           new sample every period_ms (timestamp = sampling time)
  3. ADAS ECU step            -> BRAKE_REQ (0x120) + ADAS_STATUS (0x130) sent
  4. Brake ECU step           consumes BRAKE_REQ received this step -> BRAKE_STATUS (0x220) sent
  5. Body ECU step            consumes BRAKE_STATUS / ADAS_STATUS received this step
  6. vehicle integration      ego decel = friction-limited Brake ECU actuator output
"""
from __future__ import annotations

import csv
import math
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from . import ecu_bindings as eb
from .can_bus import CanFrame, InProcessCanBus
from .scenario import Scenario
from .sensors import RadarModel
from .vehicle import InattentiveDriver, Vehicle, friction_limited_decel

KPH = 1.0 / 3.6


@dataclass
class RunResult:
    scenario_id: str
    seed: int
    collision: bool = False
    collision_time_s: float | None = None
    impact_speed_mps: float = 0.0
    min_gap_m: float = math.inf
    first_warning_s: float | None = None
    first_brake_request_s: float | None = None
    ttc_at_brake_request_s: float | None = None
    first_brake_active_s: float | None = None
    first_brake_lamp_s: float | None = None
    brake_lamp_latency_ms: float | None = None
    max_actual_decel_mps2: float = 0.0
    max_requested_decel_mps2: float = 0.0
    final_ego_speed_mps: float = 0.0
    final_adas_state: str = ""
    states_visited: list[str] = field(default_factory=list)
    dtc_flags_union: int = 0
    first_degraded_s: float | None = None
    brake_rejected_frames: int = 0
    body_rejected_frames: int = 0
    hazard_activated: bool = False
    illegal_transitions: int = 0
    brake_timeout_seen: bool = False
    first_brake_timeout_s: float | None = None
    last_brake_req_delivered_s: float | None = None
    unavailable_indicated: bool = False
    adas_step_mean_us: float = 0.0
    adas_step_max_us: float = 0.0
    steps: int = 0

    def to_dict(self) -> dict:
        d = asdict(self)
        return {k: (None if isinstance(v, float) and math.isinf(v) else v) for k, v in d.items()}


def lead_accel(sc: Scenario, t_s: float) -> float:
    a = 0.0
    for e in sc.lead_events:
        if t_s >= e.t_s:
            a = e.accel_mps2
    return a


def run_scenario(sc: Scenario, seed: int = 0, trace_path: str | Path | None = None,
                 bus: InProcessCanBus | None = None) -> RunResult:
    """Run one scenario. A pre-configured bus (e.g. with a tamper hook) may be supplied."""
    dt_ms = int(round(sc.dt_s * 1000))
    if dt_ms <= 0 or abs(dt_ms / 1000.0 - sc.dt_s) > 1e-12:
        raise ValueError("dt_s must be a whole number of milliseconds")
    rng = np.random.default_rng(seed)
    freeze = next((int(f["t_s"] * 1000) for f in sc.faults if f["type"] == "radar_freeze"), None)
    radar = RadarModel(rng, freeze_at_ms=freeze, **sc.radar)
    bus = bus or InProcessCanBus()
    drop_from = next((int(f["t_s"] * 1000) for f in sc.faults if f["type"] == "drop_brake_req"), None)
    if drop_from is not None:
        bus.drop_filter = lambda fr: fr.arbitration_id == eb.CAN_ID_BRAKE_REQ and fr.timestamp_ms >= drop_from

    adas, brake, body = eb.AdasEcu(), eb.BrakeEcu(), eb.BodyEcu()
    ego = Vehicle(0.0, sc.ego_speed_kph * KPH)
    lead = Vehicle(sc.gap0_m, sc.lead_speed_kph * KPH)
    driver = InattentiveDriver(target_speed_mps=ego.v_mps)
    res = RunResult(sc.id, seed)
    rows = []
    step_times = []
    n_steps = int(round(sc.duration_s / sc.dt_s))
    aeb_engaged = False

    for k in range(n_steps + 1):
        t_ms = k * dt_ms
        t_s = t_ms / 1000.0
        bus.advance()
        gap = lead.x_m - ego.x_m
        rel_v = lead.v_mps - ego.v_mps
        m = radar.update(t_ms, gap, rel_v)

        ai = eb.AdasInput()
        ai.now_ms, ai.function_enabled = t_ms, 1
        ai.ego_speed_valid, ai.ego_speed_mps, ai.ego_speed_ts_ms = 1, ego.v_mps, t_ms
        if m is not None:
            ai.sensor_ok, ai.object_present = int(m.sensor_ok), int(m.object_present)
            ai.range_m, ai.range_rate_mps, ai.meas_ts_ms = m.range_m, m.range_rate_mps, m.ts_ms
        else:
            ai.sensor_ok = 0
        t0 = time.perf_counter_ns()
        ao = adas.step(ai)
        step_times.append((time.perf_counter_ns() - t0) / 1000.0)
        bus.send(CanFrame(eb.CAN_ID_BRAKE_REQ, eb.frame_bytes(ao.brake_req_frame), t_ms, "ADAS"))
        bus.send(CanFrame(eb.CAN_ID_ADAS_STATUS, eb.frame_bytes(ao.adas_status_frame), t_ms, "ADAS"))

        bi = eb.BrakeInput()
        bi.now_ms, bi.dt_s, bi.driver_brake_mps2 = t_ms, sc.dt_s, 0.0
        rf = bus.receive(eb.CAN_ID_BRAKE_REQ)
        if rf is not None:
            bi.frame_present, bi.can_id, bi.frame_dlc = 1, rf.arbitration_id, len(rf.data)
            for i, b in enumerate(rf.data[:8]):
                bi.frame[i] = b
        bo = brake.step(bi)
        bus.send(CanFrame(eb.CAN_ID_BRAKE_STATUS, eb.frame_bytes(bo.status_frame), t_ms, "BRAKE"))

        yi = eb.BodyInput()
        yi.now_ms = t_ms
        bsf = bus.receive(eb.CAN_ID_BRAKE_STATUS)
        asf = bus.receive(eb.CAN_ID_ADAS_STATUS)
        if bsf is not None:
            yi.brake_status_present, yi.brake_status_dlc = 1, len(bsf.data)
            for i, b in enumerate(bsf.data[:8]):
                yi.brake_status_frame[i] = b
        if asf is not None:
            yi.adas_status_present, yi.adas_status_dlc = 1, len(asf.data)
            for i, b in enumerate(asf.data[:8]):
                yi.adas_status_frame[i] = b
        yo = body.step(yi)

        state = eb.ADAS_STATES[ao.state]
        if not res.states_visited or res.states_visited[-1] != state:
            res.states_visited.append(state)
        res.dtc_flags_union |= ao.dtc_flags
        if ao.warning_active and res.first_warning_s is None:
            res.first_warning_s = t_s
        if ao.brake_request_active:
            aeb_engaged = True
            if res.first_brake_request_s is None:
                res.first_brake_request_s = t_s
                res.ttc_at_brake_request_s = ao.ttc_s if math.isfinite(ao.ttc_s) else None
        if state == "DEGRADED" and res.first_degraded_s is None:
            res.first_degraded_s = t_s
        if bo.brake_active and res.first_brake_active_s is None:
            res.first_brake_active_s = t_s
        if yo.brake_lamp and res.first_brake_lamp_s is None:
            res.first_brake_lamp_s = t_s
        res.hazard_activated |= bool(yo.hazard_lamps)
        res.illegal_transitions = ao.illegal_transition_count
        if bo.status == 2 and res.first_brake_timeout_s is None:
            res.first_brake_timeout_s = t_s
        res.brake_timeout_seen |= bo.status == 2
        if rf is not None:
            res.last_brake_req_delivered_s = t_s
        res.unavailable_indicated |= bool(yo.aeb_unavailable_indicator) and t_ms > 100
        res.max_requested_decel_mps2 = max(res.max_requested_decel_mps2, ao.decel_request_mps2)

        # ---- plant ----
        brake_decel = friction_limited_decel(bo.actual_decel_mps2, sc.mu)
        if aeb_engaged and ego.v_mps <= 0.05:
            driver.target_speed_mps = 0.0  # DRV-A-02
        ego_a = -brake_decel if bo.actual_decel_mps2 > 0.01 else driver.accel(ego.v_mps)
        lead_a = lead_accel(sc, t_s)
        if lead_a < 0:
            lead_a = -friction_limited_decel(-lead_a, sc.mu)
        res.max_actual_decel_mps2 = max(res.max_actual_decel_mps2, max(-ego_a, 0.0))

        rows.append({
            "t_s": t_s, "ego_x_m": ego.x_m, "lead_x_m": lead.x_m, "gap_m": gap, "ego_v_mps": ego.v_mps,
            "lead_v_mps": lead.v_mps, "meas_range_m": ai.range_m, "meas_range_rate_mps": ai.range_rate_mps,
            "meas_age_ms": t_ms - ai.meas_ts_ms if ai.sensor_ok else -1, "ttc_s": ao.ttc_s if math.isfinite(ao.ttc_s) else "",
            "adas_state": state, "decel_request_mps2": ao.decel_request_mps2,
            "brake_target_mps2": bo.target_decel_mps2, "brake_actual_mps2": bo.actual_decel_mps2,
            "ego_accel_mps2": ego_a, "brake_status": bo.status, "brake_lamp": yo.brake_lamp,
            "warning": yo.warning_indicator, "hazard": yo.hazard_lamps, "unavailable": yo.aeb_unavailable_indicator,
            "dtc_flags": ao.dtc_flags,
        })
        res.min_gap_m = min(res.min_gap_m, gap)
        if gap <= 0.0:
            res.collision, res.collision_time_s = True, t_s
            res.impact_speed_mps = max(ego.v_mps - lead.v_mps, 0.0)
            break
        ego.step(sc.dt_s, ego_a)
        lead.step(sc.dt_s, lead_a)
        new_gap = lead.x_m - ego.x_m
        if new_gap <= 0.0:  # contact inside the step: record and stop
            res.collision, res.collision_time_s = True, t_s + sc.dt_s
            res.impact_speed_mps = max(ego.v_mps - lead.v_mps, 0.0)
            res.min_gap_m = 0.0
            rows[-1]["gap_m"] = gap
            break

    res.steps = len(rows)
    res.final_ego_speed_mps = ego.v_mps
    res.final_adas_state = eb.ADAS_STATES[adas.state]
    res.brake_rejected_frames = bo.rejected_frames
    res.body_rejected_frames = yo.rejected_frames
    if res.first_brake_active_s is not None and res.first_brake_lamp_s is not None:
        res.brake_lamp_latency_ms = round((res.first_brake_lamp_s - res.first_brake_active_s) * 1000.0, 3)
    if step_times:
        res.adas_step_mean_us = float(np.mean(step_times))
        res.adas_step_max_us = float(np.max(step_times))
    if trace_path is not None:
        Path(trace_path).parent.mkdir(parents=True, exist_ok=True)
        with open(trace_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    for h in (adas, brake, body):
        h.close()
    return res
