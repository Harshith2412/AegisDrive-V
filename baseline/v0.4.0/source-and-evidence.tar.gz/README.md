# AegisDrive-V

**Model-Based Automotive ECU Safety, Security and V-Model Validation Platform** — an open-source,
software-in-the-loop engineering project around an Automatic Emergency Braking (AEB) function, a simulated
Brake ECU and a Body Control Module.

> ⚠️ **Educational simulation only.** Not production software, not certified, no ISO 26262 / ISO 21448 /
> ISO/SAE 21434 compliance is claimed. Standards are used as *inspiration*; see `docs/`.

## Status — v0.4.0: Automotive Cybersecurity and Safety-Security Co-Engineering

Preserved and reproduced v0.3.0: all 79 tests and 828 experiment outcomes match, apart from
host timings. Current macOS build passes 92 tests, with 49 requirements linked to passing
tests. Added HMAC-SHA256 authentication, sender policy, full freshness/epoch checks,
explicit bounded recovery, native security diagnostics and isolated local A01–A12 attacks.
Protected messages are valid 64-byte CAN FD PDUs; test keys are public fixtures only.

[Technical release](docs/v0.4.0_release.md) · [Audit](docs/v0.4.0_audit.md) ·
[TARA](docs/v0.4.0_tara.md) · [Secure design](docs/v0.4.0_security_design.md) ·
[Safety-security matrix](docs/v0.4.0_coengineering.md) · [Evaluation](results/v0.4.0/evaluation.md) ·
[Reproduction](docs/v0.4.0_reproducibility.md)

846 matched A/B/C runs include all original 120 hold-outs plus 48 separate security cases.
Forged-source/payload cases stop causing unnecessary braking in defended modes. Correctly
signed dangerous commands from compromised producers remain hazardous. Authentication and
freshness rejection can also remove legitimate braking: new security hold-out collisions
are 0/48 (A), 12/48 (B), 6/48 (C), alongside unnecessary-braking events 15/48, 3/48, 3/48.
All modes retain 29/120 original hold-out collisions. No uniform safety improvement is claimed.

The security SysML extension and preserved architecture/requirement dependencies pass the
official pilot semantic validator; test/experiment links are checked separately. Educational
SiL gateway only: no production SecOC, standards compliance, certification, HSM or durable
freshness-storage claim. Shared actuation, perception ghosts, trusted compromise and
availability risks remain open. Historical releases and hashed baselines remain intact.

## Vertical slice in one picture
```
radar model ─► ADAS ECU (TTC, FSM, supervisor) ─CAN 0x120─► Brake ECU (validate, timeout, actuator) ─► ego vehicle
                    └────────────CAN 0x130──────► Body ECU ◄──CAN 0x220──┘   (brake lamps, FCW, hazard)
```
ADAS states: DISABLED · STANDBY · MONITORING · WARNING · BRAKING · DEGRADED · FAULT (26 legal transitions, all others rejected and logged).

## Historical v0.1.0 results (preserved; current comparison linked above)
| Scenario | Outcome (20 seeds) |
|---|---|
| S01 normal following | 0 warnings, 0 brake requests |
| S02 lead brakes 6 m/s² @ 50 km/h, 20 m gap | 0/20 collisions, but min gap only **0.58 m** (constant-velocity TTC limitation, OI-002) |
| S03 stationary target @ 50 km/h | 0/20 collisions, stops 2.4–2.6 m short; brake lamp 10 ms after brake active |
| S04 lead decelerates 1.5 m/s² | 0/20 collisions, but AEB **aborted and re-triggered** (OI-003) |
| FI01 radar freezes | detected within 160 ms → DEGRADED → FAULT; **collision 20/20** (single sensor, OI-006) |
| FI02 brake command loss | Brake ECU times out correctly; ADAS doesn't notice → **collision 20/20** (OI-001) |
| Sweep, stationary target | μ 0.9: 0 collisions 10–80 km/h · μ 0.5: collisions 100 % at ≥ 60 km/h (no friction awareness, OI-004) |
| Characterisation | forged frame with recomputed CRC **is accepted** → CRC ≠ security (OI-005, Phase 7) |

With 20 runs per point, "0 collisions" bounds the true rate only below ≈16 % (Wilson 95 %).

## Quick start (validated on macOS)

```sh
python3 -m venv .venv
.venv/bin/pip install -r results/v0.4.0/dependencies.txt
SYSML_PILOT_HOME=/path/to/sysml-0.63.1 PLANTUML_JAR=/path/to/plantuml-1.2026.2.jar scripts/run_v4.sh
```

See the reproduction record for pinned tool hashes, scope and preserved baseline reruns.
Default original scenario calls remain unauthenticated for explicit comparison; pass a
security configuration to select A/B/C in the locked security experiment manifest. ABI 4
requires rebuilding the C++ library and Python bindings together. Attacks remain local SiL.

## Repository layout
```
docs/            00–04 Phase-0 baseline, 05 design, open issues, phase status, toolchain notes
ecu/include      C ABI types (aegis_types.h, aegis_c_api.h) + C++ headers
ecu/src          ADAS, Brake, Body ECUs, CAN codecs, E2E (CRC-8 + alive counter)
ecu/tests        GoogleTest-style unit tests (tagged TEST-ID / VERIFIES)
sim/aegis_sim    ctypes bindings, virtual CAN, vehicle & radar models, runner, plotting
scenarios        YAML scenarios S01–S04, FI01–FI02
requirements     requirements.yaml (machine-readable DB)
tests/python     integration / system / fault-injection tests
tools            experiment runner, traceability checker, report generator, fallback test runner
results          generated evidence (re-created by scripts/run_all.sh)
```

## Important honesty notes
* v0.1.0 evidence was produced in a Linux sandbox **without CMake, GoogleTest, pytest, pybind11 or python-can**
  (no network). The CMake path is written but was **not executed** there (OI-011). See `docs/toolchain_notes.md`.
* Timing numbers are host FFI wall-clock times, not ECU execution times.
* v0.1.0 MC/DC was not measured. v0.2.0 has partial LLVM MC/DC evidence; see the release record.

## License
MIT — see `LICENSE`.
