#!/usr/bin/env bash
# Current release pipeline. Historical pipelines are preserved in baseline archives.
set -euo pipefail
cd "$(dirname "$0")/.."
exec scripts/run_v4.sh "$@"
