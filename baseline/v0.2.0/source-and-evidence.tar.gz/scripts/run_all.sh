#!/usr/bin/env bash
# v0.2.0 assurance pipeline. Original evidence remains under results/ and baseline/.
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"
OUT=results/v0.2.0
mkdir -p "$OUT"
cmake -S . -B build -DAEGIS_USE_MINITEST="${AEGIS_USE_MINITEST:-ON}" -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j4
./build/aegis_ecu_tests --gtest_output=json:"$OUT/cpp_test_results.json"
ctest --test-dir build --output-on-failure
"$PYTHON" -m pytest -o cache_dir="$PWD/.pytest_cache" tests/python -q --junitxml="$OUT/python_test_results.xml"
MPLCONFIGDIR="${MPLCONFIGDIR:-/private/tmp/aegis-mpl}" "$PYTHON" tools/run_vertical_slice.py --seeds 20 --out "$OUT/scenarios"
"$PYTHON" tools/evaluate_assurance.py "$OUT/paired"
"$PYTHON" tools/trace_check.py --cpp-results "$OUT/cpp_test_results.json" --py-results "$OUT/python_test_results.xml" --out "$OUT"
"$PYTHON" tools/check_assurance.py
"$PYTHON" tools/report_assurance.py
if [[ "$(uname -s)" == Darwin ]]; then
  PYTHON="$PYTHON" AEGIS_MCDC="${AEGIS_MCDC:-OFF}" scripts/coverage_llvm.sh
fi
if [[ -n "${PLANTUML_JAR:-}" ]]; then
  PYTHON="$PYTHON" scripts/validate_models.sh
  if [[ "${AEGIS_MCDC:-OFF}" == "ON" ]]; then "$PYTHON" tools/release_gate.py; fi
fi
