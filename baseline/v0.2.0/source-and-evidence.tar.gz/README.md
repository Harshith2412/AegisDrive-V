# AegisDrive-V

**Model-Based Automotive ECU Safety, Security and V-Model Validation Platform** — an open-source,
software-in-the-loop engineering project around an Automatic Emergency Braking (AEB) function, a simulated
Brake ECU and a Body Control Module.

> ⚠️ **Educational simulation only.** Not production software, not certified, no ISO 26262 / ISO 21448 /
> ISO/SAE 21434 compliance is claimed. Standards are used as *inspiration*; see `docs/`.

## Status — v0.2.0: Functional Safety, MBSE and ECU Integration Assurance

macOS CMake build verified; 39 C++ + 23 Python tests pass; 39 requirements link to executed
tests. Added brake feedback/command acknowledgment, conservative stopping envelope, and
release hysteresis. Provisional HARA, FSC/FSRs, TSC/TSRs, FMEA/FTA and five validated UML
models are recorded. The SysML v2 structural model remains unvalidated.

[Release gate](docs/v0.2.0_release.md) · [Before/after evaluation](results/v0.2.0/evaluation.md) ·
[Safety analysis](docs/v0.2.0_safety.md) · [Models](models/README.md) ·
[Reproducibility](docs/v0.2.0_reproducibility.md) · [Safety trace](results/v0.2.0/safety_trace.md)

S02 minimum separation: 0.58 → 7.77 m; S04 retriggers: 20 → 0 across 20 seeds.
Wet stationary-target 60/80 km/h collisions: 20/20 → 0/20 at mu=0.5.
FI01 and FI02 remain 20/20 collisions; diagnosis does not supply redundant sensing or braking.
The original v0.1.0 source and evidence are preserved in `baseline/v0.1.0/`.
This is an educational research release with open safety issues and provisional ASIL proposals.

## Vertical slice in one picture
```
radar model ─► ADAS ECU (TTC, FSM, supervisor) ─CAN 0x120─► Brake ECU (validate, timeout, actuator) ─► ego vehicle
                    └────────────CAN 0x130──────► Body ECU ◄──CAN 0x220──┘   (brake lamps, FCW, hazard)
```
ADAS states: DISABLED · STANDBY · MONITORING · WARNING · BRAKING · DEGRADED · FAULT (26 legal transitions, all others rejected and logged).

## Historical v0.1.0 results (preserved; current comparison linked above)
| Scenario | Outcome (20 seeds) |
|---|---|
| S01 normal following | 0 warnings, 0 brake requests |
| S02 lead brakes 6 m/s² @ 50 km/h, 20 m gap | 0/20 collisions, but min gap only **0.58 m** (constant-velocity TTC limitation, OI-002) |
| S03 stationary target @ 50 km/h | 0/20 collisions, stops 2.4–2.6 m short; brake lamp 10 ms after brake active |
| S04 lead decelerates 1.5 m/s² | 0/20 collisions, but AEB **aborted and re-triggered** (OI-003) |
| FI01 radar freezes | detected within 160 ms → DEGRADED → FAULT; **collision 20/20** (single sensor, OI-006) |
| FI02 brake command loss | Brake ECU times out correctly; ADAS doesn't notice → **collision 20/20** (OI-001) |
| Sweep, stationary target | μ 0.9: 0 collisions 10–80 km/h · μ 0.5: collisions 100 % at ≥ 60 km/h (no friction awareness, OI-004) |
| Characterisation | forged frame with recomputed CRC **is accepted** → CRC ≠ security (OI-005, Phase 7) |

With 20 runs per point, "0 collisions" bounds the true rate only below ≈16 % (Wilson 95 %).

## Quick start (validated on macOS)

```sh
python3 -m venv .venv
.venv/bin/pip install -r results/v0.2.0/dependencies.txt
scripts/run_all.sh
# Include supported MC/DC and model parser/render validation:
AEGIS_MCDC=ON PLANTUML_JAR=/path/to/plantuml-1.2026.2.jar scripts/run_all.sh
```

The default uses CMake, bundled minitest, pytest and deterministic CAN. See the reproducibility
record for exact versions, baseline reruns, supported coverage scope and model validation.
ABI 2 and CAN status extensions require coordinated ECU/binding updates.

## Repository layout
```
docs/            00–04 Phase-0 baseline, 05 design, open issues, phase status, toolchain notes
ecu/include      C ABI types (aegis_types.h, aegis_c_api.h) + C++ headers
ecu/src          ADAS, Brake, Body ECUs, CAN codecs, E2E (CRC-8 + alive counter)
ecu/tests        GoogleTest-style unit tests (tagged TEST-ID / VERIFIES)
sim/aegis_sim    ctypes bindings, virtual CAN, vehicle & radar models, runner, plotting
scenarios        YAML scenarios S01–S04, FI01–FI02
requirements     requirements.yaml (machine-readable DB)
tests/python     integration / system / fault-injection tests
tools            experiment runner, traceability checker, report generator, fallback test runner
results          generated evidence (re-created by scripts/run_all.sh)
```

## Important honesty notes
* v0.1.0 evidence was produced in a Linux sandbox **without CMake, GoogleTest, pytest, pybind11 or python-can**
  (no network). The CMake path is written but was **not executed** there (OI-011). See `docs/toolchain_notes.md`.
* Timing numbers are host FFI wall-clock times, not ECU execution times.
* v0.1.0 MC/DC was not measured. v0.2.0 has partial LLVM MC/DC evidence; see the release record.

## License
MIT — see `LICENSE`.
